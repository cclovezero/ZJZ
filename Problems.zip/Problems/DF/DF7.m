function varargout = DF7(Operation,Global,input)
% <problem> <A>
% Comparison of Dynamic Multiobjective Evolutionary Algorithms: Empirical Results
% operator --- EAreal

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    switch Operation
        case 'init'
            Global.M        = 2;
            Global.D        = 10;
            
            Global.lower    = [1, zeros(1,Global.D-1)];
%             Global.lower    = - Global.lower; %全置-1
%             Global.lower(1) = 0;
            
            Global.upper    = [4, ones(1,Global.D-1)]; 
            Global.operator = @EAreal;
            
            PopDec    = rand(input,Global.D);
            varargout = {PopDec};
        case 'value'%F值
            PopDec = input;
%             PopObj(:,1) = PopDec(:,1);
%             t = floor(obj.FE/obj.N/obj.taut)/obj.nt;
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);            
            a = 5*cos(0.5*pi*t);
            b = exp(a.*( PopDec(:,1) - 2.5 ));
            tmp = 1./(1 + b);
            %tmp = 1./(1 + exp(a.*( PopDec(:,1) - 2.5 )));
            g = 1 + sum(( PopDec(:,2:end) - tmp).^2 ,2);
            PopObj(:,1) = g.*(1 + t)./PopDec(:,1);
            PopObj(:,2) = g.*PopDec(:,1)/(1 + t);
            
            PopCon = [];
            
            varargout = {input,PopObj,PopCon};
        case 'PF'
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);
            G = 5*cos(0.5*pi*t);
            G = round(G*1e6)/1e6;
            x = linspace(1,4,Global.N)';
%             obj.Optimums = {};
            f1 = (1 + t)./x;
            f2 = x/(1 + t);
            f(:,1) = f1;
            f(:,2) = f2;
%             f      = f(NDSort(f,1)==1,:);


            varargout = {f};
    end
end