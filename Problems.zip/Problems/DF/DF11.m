function varargout = DF11(Operation,Global,input)
% <problem> <A>
% Comparison of Dynamic Multiobjective Evolutionary Algorithms: Empirical Results
% operator --- EAreal

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    switch Operation
        case 'init'
            Global.M        = 3;
            Global.D        = 10;
            
            Global.lower    = zeros(1,Global.D);
            Global.upper    = ones(1,Global.D); 
            Global.operator = @EAreal;
%             Global.encoding = ones(1,Global.D);
            
            PopDec    = rand(input,Global.D);
            varargout = {PopDec};
        case 'value'%F值
            PopDec = input;
            PopObj(:,1) = PopDec(:,1);
%             t = floor(obj.FE/obj.N/obj.taut)/obj.nt;
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);            
            G = abs(sin(0.5*pi*t));
            G = round(G*1e6)/1e6;
            y1 = pi*G/6 + (pi/2 - pi*G/3)*PopDec(:,1);
            y2 = pi*G/6 + (pi/2 - pi*G/3)*PopDec(:,2);
            g = 1 + G + sum((PopDec(:,3:end) - 0.5*G*PopDec(:,1)).^2,2);
            PopObj(:,1) = g.*sin(y1);
            PopObj(:,2) = g.*sin(y2).*cos(y1);
            PopObj(:,3) = g.*cos(y2).*cos(y1);
            PopCon = [];
            
            varargout = {input,PopObj,PopCon};
        case 'PF'
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);
            h = 50;
            G = abs(sin(0.5*pi*t));
            G = round(G*1e6)/1e6;
            [X,Y] = meshgrid(linspace(0,1,h));
            PS = [];
            for i = 1:size(X,1)
                PS = [PS
                    [X(:,i) Y(:,i)]];
            end
            x1 = PS(:,1);
            x2 = PS(:,2);
                y1 = pi*G/6 + (pi/2 - pi*G/3)*x1;
                y2 = pi*G/6 + (pi/2 - pi*G/3)*x2;
                f(:,1) = sin(y1);
                f(:,2) = sin(y2).*cos(y1);
                f(:,3) = cos(y2).*cos(y1);

            varargout = {f};
    end
end