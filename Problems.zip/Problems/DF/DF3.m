function varargout = DF3(Operation,Global,input)
% <problem> <A>
% Comparison of Dynamic Multiobjective Evolutionary Algorithms: Empirical Results
% operator --- EAreal

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    switch Operation
        case 'init'
            Global.M        = 2;
            Global.D        = 10;
            
            Global.lower    = [0,-ones(1,Global.D-1)];
%             Global.lower    = - Global.lower; %全置-1
%             Global.lower(1) = 0;
            
            Global.upper    = [1, 2*ones(1,Global.D-1)]; 
            Global.operator = @EAreal;
            
            PopDec    = rand(input,Global.D);
            varargout = {PopDec};
        case 'value'%F值
            PopDec = input;
            PopObj(:,1) = PopDec(:,1);
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);
%             t = floor(obj.FE/obj.N/obj.taut)/obj.nt;
            G = sin(0.5*pi*t);
            H = sin(0.5*pi*t)+1.5;
            g = 1 + sum((PopDec(:,2:end) - G - (PopDec(:,1)).^H).^2, 2);
            h = 1-(PopObj(:,1)./g).^H;
            PopObj(:,2) = g.*h;
            
            PopCon = [];
            
            varargout = {input,PopObj,PopCon};
        case 'PF'
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);
            H = sin(0.5*pi*t) + 1.5;
            H = round(H*1e6)/1e6;
            x = (0:1/(input-1):1)';

            f(:,1) = x;
            f(:,2) = 1 - x.^H;

            varargout = {f};
    end
end