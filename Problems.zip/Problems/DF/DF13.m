function varargout = DF13(Operation,Global,input)
% <problem> <A>
% Comparison of Dynamic Multiobjective Evolutionary Algorithms: Empirical Results
% operator --- EAreal

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    switch Operation
        case 'init'
            Global.M        = 3;
            Global.D        = 10;
            
            Global.lower    = [0,0,-ones(1,Global.D-2)];
            Global.upper    = [1,1,ones(1,Global.D-2)]; 
            Global.operator = @EAreal;
%             Global.encoding = ones(1,Global.D);
            
            PopDec    = rand(input,Global.D);
            varargout = {PopDec};
        case 'value'%F值
            PopDec = input;
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);            
            G = sin(0.5*pi*t);
            G = round(G*1e6)/1e6;
            p = floor(6*G);
            g = 1 + sum((PopDec(:,3:end) - G).^2, 2);         
            PopObj(:,1) = g.*cos(0.5*pi*PopDec(:,1)).^2;
            PopObj(:,2) = g.*cos(0.5*pi*PopDec(:,2)).^2;
            PopObj(:,3) = g.*(sin(0.5*pi*PopDec(:,1)).^2 + sin(0.5*pi*PopDec(:,1)).*cos(p*pi*PopDec(:,1)).^2 +...
            sin(0.5*pi*PopDec(:,2)).^2 + sin(0.5*pi*PopDec(:,2)).*cos(p*pi*PopDec(:,2)).^2);
            
            PopCon = [];
            varargout = {input,PopObj,PopCon};
        case 'PF'
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);
            h = 50;
            G = sin(0.5*pi*t);
            G = round(G*1e6)/1e6;
            p = floor(6*G);
            [X,Y] = meshgrid(linspace(0,1,h));
            PS = [];
            for i = 1:size(X,1)
                PS = [PS
                    [X(:,i) Y(:,i)]];
            end
            x1 = PS(:,1);
            x2 = PS(:,2);
                f(:,1) = cos(0.5*pi*x1).^2;
                f(:,2) = cos(0.5*pi*x2).^2;
                f(:,3) = sin(0.5*pi*x1).^2 + sin(0.5*pi*x1).*cos(p*pi*x1).^2 +...
                sin(0.5*pi*x2).^2 + sin(0.5*pi*x2).*cos(p*pi*x2).^2;

                f      = f(NDSort(f,1)==1,:);

            varargout = {f};
    end
end