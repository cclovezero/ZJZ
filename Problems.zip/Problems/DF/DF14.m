function varargout = DF14(Operation,Global,input)
% <problem> <A>
% Comparison of Dynamic Multiobjective Evolutionary Algorithms: Empirical Results
% operator --- EAreal

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    switch Operation
        case 'init'
            Global.M        = 3;
            Global.D        = 10;
            
            Global.lower    = [0,0,-ones(1,Global.D-2)];
            Global.upper    = [1,1,ones(1,Global.D-2)]; 
            Global.operator = @EAreal;
%             Global.encoding = ones(1,Global.D);
            
            PopDec    = rand(input,Global.D);
            varargout = {PopDec};
        case 'value'%F值
            PopDec = input;
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);            
            G = sin(0.5*pi*t);
            G = round(G*1e6)/1e6;
            g = 1 + sum((PopDec(:,3:end) - G).^2,2);
            y = 0.5 + G*(PopDec(:,1) - 0.5);
            PopObj(:,1) = g.*(1 - y + 0.05*sin(6*pi*y));
            PopObj(:,2) = g.*(1 - PopDec(:,2) + 0.05*sin(6*pi*PopDec(:,2))).*(y + 0.05*sin(6*pi*y));
            PopObj(:,3) = g.*(PopDec(:,2) + 0.05*sin(6*pi*PopDec(:,2))).*(y + 0.05*sin(6*pi*y));

            PopCon = [];
            varargout = {input,PopObj,PopCon};
        case 'PF'
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);
            h = 50;
            G = sin(0.5*pi*t);
            G = round(G*1e6)/1e6;
            [X,Y] = meshgrid(linspace(0,1,h));
            %[X,Y] = meshgrid(0:.077:1, 0:.077:1);
            PS = [];
            for i = 1:size(X,1)
                PS = [PS
                    [X(:,i) Y(:,i)]];
            end
            x1 = PS(:,1);
            x2 = PS(:,2);
                y1 = 0.5 + G*(x1-0.5);
                f(:,1) = 1 - y1 + 0.05*sin(6*pi*y1);
                f(:,2) = (1 - x2 + 0.05*sin(6*pi*x2)).*( y1 + 0.05*sin(6*pi*y1));
                f(:,3) = ( x2 + 0.05*sin(6*pi*x2)).*(y1 + 0.05*sin(6*pi*y1));

            varargout = {f};
    end
end