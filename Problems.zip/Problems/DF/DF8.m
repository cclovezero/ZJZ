function varargout = DF8(Operation,Global,input)
% <problem> <A>
% Comparison of Dynamic Multiobjective Evolutionary Algorithms: Empirical Results
% operator --- EAreal

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    switch Operation
        case 'init'
            Global.M        = 2;
            Global.D        = 10;
            
            Global.lower    = [0, -ones(1,Global.D-1)];
%             Global.lower    = - Global.lower; %全置-1
%             Global.lower(1) = 0;
            
            Global.upper    = [1, ones(1,Global.D-1)]; 
            Global.operator = @EAreal;
            
            PopDec    = rand(input,Global.D);
            varargout = {PopDec};
        case 'value'%F值
            PopDec = input;
            PopObj(:,1) = PopDec(:,1);
%             t = floor(obj.FE/obj.N/obj.taut)/obj.nt;
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);            
            G = sin(0.5*pi*t);
            a = 2.25 + 2*cos(2*pi*t);
            b = 100*G.^2;
            temp = G*sin(4*pi*(power(PopDec(:,1),b)))/(1+abs(G));
            g = 1 + sum(( PopDec(:,2:end) - temp).^2, 2);
            PopObj(:,1) = g.*(PopDec(:,1) + 0.1*sin(3*pi*PopDec(:,1)));
            PopObj(:,2) = g.*(1 - PopDec(:,1) + 0.1*sin(3*pi*PopDec(:,1))).^a;
            
            PopCon = [];
            
            varargout = {input,PopObj,PopCon};
        case 'PF'
            t =(1/Global.NT)* floor(Global.Current()/Global.tao_n);
            G = sin(0.5*pi*t);
            G = round(G*1e6)/1e6;
            a = 2.25 + 2*cos(2*pi*t);
            a = round(a*1e6)/1e6;
            x = linspace(0,1,Global.N)';
            obj.Optimums = {};
            f(:,1) = x + 0.1*sin(3*pi*x);
            f(:,2) = (1 - x + 0.1*sin(3*pi*x)).^a;
%             f      = f(NDSort(f,1)==1,:);


            varargout = {f};
    end
end